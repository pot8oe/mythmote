package tkj.android.homecontrol.mythmote;

import java.util.List;

import tkj.android.homecontrol.mythmote.KeyBindingManager.MythKey;

import android.app.AlertDialog;
import android.content.ContentValues;
import android.content.Context;
import android.content.DialogInterface;
import android.content.DialogInterface.OnClickListener;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

public class KeyBindingDbAdapter {

	private static final String ROWID = "_id";
	private static final String COMMAND = "myth_command";
	private static final String UI_KEY = "ui_key";
	private static final String FRIENDLY_NAME = "friendly_name";

	private static final String TAG = "LocationDbAdapter";
	private DatabaseHelper mDbHelper;
	private SQLiteDatabase mDb;

	private static final String DATABASE_NAME = "mythmotedata";
	private static final String DATABASE_TABLE = "keybindings";
	private static final int DATABASE_VERSION = 1;

	/**
	 * Database creation sql statement
	 */
	private static final String DATABASE_CREATE = "create table "
			+ DATABASE_TABLE + " (" + ROWID
			+ " integer primary key autoincrement, " + COMMAND
			+ " text not null, " + UI_KEY + " text not null, " + FRIENDLY_NAME
			+ " text not null);";

	private final Context mCtx;

	private static class DatabaseHelper extends SQLiteOpenHelper {

		DatabaseHelper(Context context) {
			super(context, DATABASE_NAME, null, DATABASE_VERSION);
		}

		@Override
		public void onCreate(SQLiteDatabase db) {

			db.execSQL(DATABASE_CREATE);
		}

		@Override
		public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
			Log.w(TAG, "Upgrading database from version " + oldVersion + " to "
					+ newVersion + ", which will destroy all old data");
			db.execSQL("DROP TABLE IF EXISTS " + DATABASE_TABLE);
			onCreate(db);
		}
	}

	/**
	 * Constructor - takes the context to allow the database to be
	 * opened/created
	 * 
	 * @param ctx
	 *            the Context within which to work
	 */
	public KeyBindingDbAdapter(Context ctx) {
		this.mCtx = ctx;
	}

	/**
	 * Open the notes database. If it cannot be opened, try to create a new
	 * instance of the database. If it cannot be created, throw an exception to
	 * signal the failure
	 * 
	 * @return this (self reference, allowing this to be chained in an
	 *         initialization call)
	 * @throws SQLException
	 *             if the database could be neither opened or created
	 */
	private KeyBindingDbAdapter open() throws SQLException {
		mDbHelper = new DatabaseHelper(mCtx);
		mDb = mDbHelper.getWritableDatabase();
		return this;
	}

	private void close() {
		mDbHelper.close();
	}

	private long save(final KeyBindingEntry entry) {
		long rval = 0;

		try {
			open();
			ContentValues values = new ContentValues();
			values.put(COMMAND, entry.getCommand());
			values.put(UI_KEY, entry.getMythKey().name());
			values.put(FRIENDLY_NAME, entry.getFriendlyName());
			rval = mDb.insert(DATABASE_TABLE, null, values);
			close();
		} catch (SQLException e) {
			AlertDialog.Builder builder = new AlertDialog.Builder(mCtx);
    		builder.setTitle("Unable to save key binding entries");
    		builder.setMessage(e.getLocalizedMessage());
    		builder.show();
		}
		return rval;

	}

	/**
	 * Clear the existing list of key binding entries, and save this list
	 * 
	 * @param entries
	 *            the full list of entries to save
	 * @return true if all entries were saved
	 */
	public boolean clearAndSave(final List<KeyBindingEntry> entries) {
		if (mDb.delete(DATABASE_TABLE, "1", null) > 0) {
			long numInserted = 0;
			for (KeyBindingEntry entry : entries) {
				numInserted += save(entry);
			}
			return numInserted == entries.size();
		}
		return false;
	}

	/**
	 * Load the persisted list of key bindings from the database
	 * 
	 * @param binder
	 *            the binder which will accept a key binding
	 */
	public void loadKeyMapEntries(final KeyMapBinder binder) {
		final Cursor rowCursor = mDb.query(DATABASE_TABLE, new String[] {
				ROWID, COMMAND, UI_KEY, FRIENDLY_NAME }, null, null, null,
				null, null);
		if (null == rowCursor)
			return; // TODO handle this
		rowCursor.moveToFirst();
		do {
			String friendlyName = rowCursor.getString(rowCursor
					.getColumnIndex(FRIENDLY_NAME));
			String mythKeyName = rowCursor.getString(rowCursor
					.getColumnIndex(UI_KEY));
			String command = rowCursor.getString(rowCursor
					.getColumnIndex(FRIENDLY_NAME));
			MythKey key = MythKey.getByName(mythKeyName);
			KeyBindingEntry entry = new KeyBindingEntry(friendlyName, key,
					command);
			binder.bind(entry);
		} while (rowCursor.moveToNext());
	}
}

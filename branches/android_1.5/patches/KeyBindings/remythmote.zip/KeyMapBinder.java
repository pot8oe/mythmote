package tkj.android.homecontrol.mythmote;

public interface KeyMapBinder {
	public void bind(final KeyBindingEntry entry);
}

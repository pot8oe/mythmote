package tkj.android.homecontrol.mythmote;

import static tkj.android.homecontrol.mythmote.R.id.*;

public class KeyBindingManager {
	
	/**
	 * Add a value here which is the button name (preferably similar to the layout id) and the default action
	 * @author robelsner
	 *
	 */
	public enum MythKey {
		BUTTON_0("0", Button0),
		BUTTON_1("1", Button1),
		BUTTON_2("2", Button2),
		BUTTON_3("3", Button3),
		BUTTON_4("4", Button4),
		BUTTON_5("5", Button5),
		BUTTON_6("6", Button6),
		BUTTON_7("7", Button7),
		BUTTON_8("8", Button8),
		BUTTON_9("9", Button9),
		BUTTON_BACKSPACE("backspace", ButtonBackspace),
		BUTTON_CHANNEL_DOWN("channel down", ButtonChDown),
		BUTTON_CHANNEL_UP("channel up", ButtonChUp),
		BUTTON_CHANNEL_RECALL("h", ButtonChReturn),
		BUTTON_ESCAPE("escape", ButtonEsc),
		BUTTON_ENTER("enter", ButtonEnter),
		BUTTON_RECORD("r", ButtonRecord),
		BUTTON_STOP("stop", ButtonStop),
		BUTTON_PLAY("speed normal", ButtonPlay),
		BUTTON_PAUSE("p", ButtonPause),
		BUTTON_DOWN("down", ButtonDown),
		BUTTON_UP("up", ButtonUp),
		BUTTON_LEFT("left", ButtonLeft),
		BUTTON_SELECT("enter", ButtonSelect),		
		BUTTON_FAST_FORWARD("seek forward", ButtonFF),
		BUTTON_REWIND("seek backward", ButtonRew),
		BUTTON_SKIP_FORWARD("end", ButtonSkipForward),
		BUTTON_SKIP_BACKWARD("home", ButtonSkipBack),
        BUTTON_GUIDE("s", ButtonGuide),
        BUTTON_INFO("i", ButtonInfo),
        BUTTON_JUMP_1("mainmenu", ButtonJump1),
        BUTTON_JUMP_2("livetv", ButtonJump2),
        BUTTON_JUMP_3("playbackrecordings", ButtonJump3),
        BUTTON_JUMP_4("playmusic", ButtonJump4),
        BUTTON_JUMP_5("videogallery", ButtonJump5),
        BUTTON_JUMP_6("statusbox", ButtonJump6),
        BUTTON_MENU("m", ButtonMenu),
        BUTTON_MUTE("|", ButtonMute),
        BUTTON_VOLUME_UP("]", ButtonVolUp),
        BUTTON_VOLUME_DOWN("[", ButtonVolDown)
        ;
        private final String defaultCommand;
        private final int layoutId;

		private MythKey(final String command, final int layoutId) {
			this.defaultCommand = command;
			this.layoutId = layoutId;
		}

		public final String getDefaultCommand() {
			return defaultCommand;
		}
		
		public final int getButtonId() {
			return layoutId;
		}
		
		public static MythKey getByName(final String name) {
			for ( MythKey key : MythKey.values()) {
				if ( key.name().equals(name))
					return key;
			}
			return MythKey.BUTTON_0;
		}
	}
	
	public KeyBindingManager() {
		
	}
	
	private void loadKeyBindings() {
		
	}

}
